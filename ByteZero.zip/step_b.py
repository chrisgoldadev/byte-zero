"""Following code tranforms provided dataset. After its analysis it is necessary to create proper and clean dataframe ready-to-go to be loaded to SQL."""

from syspytools import PyTools as pt
import pandas as pd
import os
from sqlalchemy import create_engine

print(f'Starting file analysis at: {pt.datetime_holder()}.')
start = pt.datetime_holder()
# establishing variables
print('Establishing variables...')
BASE_DIR = os.getcwd()
csv = 'data_set_da_test.csv'
path = os.path.join(BASE_DIR, csv)
response = None

print(f'Reading {csv} with pandas...')        
df = pd.read_csv(path, delimiter=',')

print('Dataframe sample...')
print(df.head(5))
print('...')
print(df.tail(5))

print('Checking data-types...')
print(df.dtypes)

print('Adjusting data-types...')
df = df.astype({
    'event_date': 'datetime64[ns]'
})

print('Preparing for loading data to sql...')
print("This part is a simulation of real data load. For purpose of this excercise, MySql server has been set up on local host. As code works on local PC, it won't be working on any other machine. Open 'step_b.py' file in editor to see steps related for data load to SQL.")

if pt.get_user_confirmation() == True:
    print('Creating engine...')
    # engine = pt.py_sql_connector()
    # sql_table = 'EVENTS_WEBSITE'
    print('Loading to sql...')
    # with engine.begin() as conn:
    #     df.to_sql(sql_table, conn, index=False, if_exists='replace')
    print(f'Loaded to sql: 637238 rows.')
    pass
    
end = pt.datetime_holder()
elapsed = end - start

print(f'Script finished in: {elapsed} seconds')




