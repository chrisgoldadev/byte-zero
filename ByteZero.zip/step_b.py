"""
This script is designed to preprocess the dataframe base on deep analysis in step_a.py file and load data to sql.
In production environment such many prints of steps are in fact not in place, this is for demo purposes to show processing of each step and give a user hints of what is in fact happening.
Part for loading to SQL has implemented attribute if_exists='replace', this is basic load to sql without setting up a table in SQL database. This option can be used in development, in production table should be created manually in SQL developer tool (SSMS for instance) with proper data types and NN (not nulls) also specifying PK and FK (primary and foreign keys).
"""

from pwinput import pwinput
from sqlalchemy import create_engine
import pandas as pd
import os
from datetime import datetime

BASE_DIR = os.getcwd()
csv = 'data_set_da_test.csv'
filepath = os.path.join(BASE_DIR, csv)

def connect_to_database():
    print('Connecting to Azure SQL database.')
    print('When prompted please enter username and password provided by email...')
    
    driver = 'ODBC Driver 17 for SQL Server'
    server = 'demo-sql-azure.database.windows.net'
    database = 'az-demo-mssql-db'
    user = input('Enter Username: ')
    password = pwinput('Enter Password: ', mask="*")

    connection_string = f'mssql+pyodbc://{user}:{password}@{server}/{database}?driver={driver}'
    engine = create_engine(connection_string)
    print('Checking connection...')
    try:
        engine.connect()
        engine.dispose()
        print('Connection established.')
        print('Engine can be used for further db connections.')
    except Exception as e:
        error_message = str(e)
        if 'Login failed for user' in error_message:
            print('Invalid username or password. Please try again.')
        elif 'Cannot open database' in error_message:
            print('The specified database does not exist or is unavailable.')
        elif 'pyodbc.InterfaceError' in error_message:
            print('Error with the ODBC driver. Ensure it is installed and correctly specified.')
        elif 'network-related' in error_message or 'server was not found' in error_message:
            print('Network issue: Unable to connect to the server. Check your connection and server name.')
        else:
            print(f'An unknown error occurred: {error_message}')
    
    return engine

def preprocess_data(filepath):
    # Load the dataset
    print("Loading dataset...")
    # setting dtype = 'object' makes sure all data will be read as string, this option ensures that all columns will be strings and we can convert to desired datatypes in next steps avoiding any conflicts
    df = pd.read_csv(filepath, delimiter=',', dtype='object')
    
    # Step 1: Remove duplicate rows
    # first analysis in step_a.py file shows duplicate values/rows in the dataset, assuming this is a straming data, it is hoghly propable that duplicates are in fact error rows, as it will be mostly impossible to create two same sessions of a user website entry at the same time
    print("Removing duplicate rows...")
    df = df.drop_duplicates()
    print(f'Number of rows after removing duplicates: {len(df)}')
    
    # Step 2: Handle data types and conversions
    
    # Convert `event_date` to datetime, ate setting up type to 'object' we need to make sure timestamp data will be in fact datetime64[ns] dtype, later on it will allow us to create time-series plots in BI tools
    print("Converting `event_date` to datetime...")
    df['event_date'] = pd.to_datetime(df['event_date'], errors='coerce')
    
    # Convert `product` to string (assuming it's an identifier and PK of another SQL table, PK data types should match each tables in database schema)
    print("Converting `product` to string...")
    df['product'] = df['product'].astype(str)
    
    # Step 3: Check for missing values
    # analysis in step_a.py file shows we got no null values, but for consistency we can implement this check into the function
    print("Checking for missing values...")
    missing_values = df.isnull().sum()
    if missing_values.any():
        print("Missing values detected:")
        print(missing_values)
    else:
        print("No missing values detected.")
    
    # Step 4: Clean and standardize `page_type` and `event_type` columns
    # also for consistency we can make sure all attributes like page_type or event_type will be in fact lower in case any other case would be in the dataset, this will make sure later in the BI tool we will have distinct value of attributes
    print("Cleaning `page_type` and `event_type` columns...")
    df['page_type'] = df['page_type'].str.lower()
    df['event_type'] = df['event_type'].str.lower()
    
    # Display unique values in `page_type` and `event_type`
    print("Unique values in `page_type` after cleaning:")
    print(df['page_type'].unique())
    print("\nUnique values in `event_type` after cleaning:")
    print(df['event_type'].unique())
    
    # Step 5: Data Summary After Preprocessing
    print("\nData Summary After Preprocessing:")
    print(f'Total rows: {len(df)}')
    print(f'Total columns: {df.shape[1]}')
    
    # Display a few rows of the cleaned dataframe
    print("\nFirst few rows of the cleaned dataset:")
    print(df.head())

    return df
    
        
if __name__ == '__main__':
    # data preprocessing
    print('Dataset preprocessing...')
    df = preprocess_data(filepath)
    
    # data loading to SQL
    print('Dataset load to SQL database...')
    # setting up an engine using pre-defined 'connect_to_database' function
    engine = connect_to_database()
    
    # with successfully connected engine we can start process of loading to SQL
    # first let's define variables necessary for successfull load
    table = 'DEV_AUTODOC_EVENTS'
    with engine.begin() as conn:
        try:
            print('Starting process of data load to SQL...')
            print('Estimated time: 0:05:00 Minutes')
            start = datetime.now()
            df.to_sql(table, conn, index=False, if_exists='replace')
            end = datetime.now()
            elapsed = end - start
            print(f'Loaded to SQL in {elapsed}')
        except Exception as e:
            print(f'An error occured during data load to SQL: {e}')
            



