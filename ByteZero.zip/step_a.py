"""Following code connects to dataset provided and analyse its structure. Instead of analysing each element separately, using ydata-profiler can significantly improve data understanding and findings of any abnormal records."""

from ydata_profiling import ProfileReport
from syspysqlconnector import PySqlConnector as psc
from syspytools import PyTools as pt
import pandas as pd
import os
import webbrowser

print(f'Starting file analysis at: {pt.datetime_holder()}.')
start = pt.datetime_holder()
# establishing variables
print('Establishing variables...')
BASE_DIR = os.getcwd()
csv = 'data_set_da_test.csv'
path = os.path.join(BASE_DIR, csv)

print(f'Reading {csv} with pandas...')        
df = pd.read_csv(path, delimiter=',')

print('Creating dataframe profile...')
profile = ProfileReport(
    df, 
    title='dataset_profile.html'
    )

filename = r'dataset_profile.html'
save_to = os.path.join(BASE_DIR, filename)
print(f'Saving profile to: {save_to}')
profile.to_file(filename)

print('Opening dataset profile...')
webbrowser.open(save_to)
end = pt.datetime_holder()
elapsed = (end - start)

print(f'Script finished in: {elapsed} seconds')

