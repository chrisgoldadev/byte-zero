"""
The script is designed to analyze a dataset and generate a comprehensive profiling report to help understand its structure, identify potential issues, and derive initial insights. The profiling step is a main part for preparing further dataframe pre-processing and loading to SQL.
"""

from ydata_profiling import ProfileReport
import pandas as pd
import os
import webbrowser
from datetime import datetime

def datetime_holder():
    """Returns the current timestamp."""
    return datetime.now()

def load_dataset(file_path):
    """
    Load dataset from a file.
    
    Args:
        file_path (str): Path to the dataset file.
    
    Returns:
        pd.DataFrame: Loaded dataset as a pandas DataFrame.
    
    Raises:
        FileNotFoundError: If the file does not exist.
    """
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"The file {file_path} does not exist. Please check the file path.")
    print(f"Reading dataset from {file_path}...")
    return pd.read_csv(file_path, delimiter=',')

def create_profile(df, output_file):
    """
    Generate and save a dataset profile using ydata-profiling.
    
    Args:
        df (pd.DataFrame): DataFrame to profile.
        output_file (str): Path to save the profile HTML report.
    
    Returns:
        str: Path to the saved profile report.
    """
    print("Generating dataset profile...")
    profile = ProfileReport(df, title="Dataset Profile", explorative=True)
    profile.to_file(output_file)
    print(f"Profile saved to: {output_file}")
    return output_file

def summarize_dataset(df):
    """
    Summarize basic information about the dataset.
    
    Args:
        df (pd.DataFrame): DataFrame to summarize.
    """
    print("\n--- Dataset Summary ---")
    print(f"Total rows: {df.shape[0]}")
    print(f"Total columns: {df.shape[1]}")
    print("\nMissing values per column:")
    print(df.isnull().sum())
    print("\nUnique values in key columns:")
    for column in ['page_type', 'event_type']:
        if column in df.columns:
            print(f"  {column}:")
            print(df[column].value_counts())
    print("\nChecking for duplicate rows...")
    duplicates = df.duplicated().sum()
    print(f"Number of duplicate rows: {duplicates}")

def main():
    """Main function to analyze the dataset."""
    print(f"Script started at: {datetime_holder()}")
    start_time = datetime_holder()

    # Define paths
    BASE_DIR = os.getcwd()
    DATA_FILE = 'data_set_da_test.csv'
    OUTPUT_FILE = 'dataset_profile.html'
    data_path = os.path.join(BASE_DIR, DATA_FILE)
    profile_path = os.path.join(BASE_DIR, OUTPUT_FILE)

    try:
        # Load dataset
        df = load_dataset(data_path)

        # Summarize dataset
        summarize_dataset(df)

        # Create and save profile
        profile_file = create_profile(df, profile_path)

        # Open profile in browser
        print("Opening profile in browser...")
        webbrowser.open(profile_file)

    except Exception as e:
        print(f"An error occurred: {e}")

    end_time = datetime_holder()
    elapsed_time = end_time - start_time
    print(f"Script finished in: {elapsed_time} seconds")

if __name__ == "__main__":
    main()


